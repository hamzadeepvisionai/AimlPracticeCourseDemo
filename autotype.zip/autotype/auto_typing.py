import subprocess
import time
import pyautogui

text = """Hello! 
This is a real-time streaming text demo.

The text will appear in Notepad
character by character, just like a stream.
"""

# Open Notepad
subprocess.Popen("notepad.exe")

# Wait for Notepad
time.sleep(2)

# Stream the text
for character in text:
    pyautogui.write(character)
    time.sleep(0.03)

print("Streaming completed!")